# Aura by Preethi — premium fashion storefront

A responsive Next.js storefront concept based on the supplied Aura by Preethi logo and visual reference. Palette: ivory cream `#F7F1E8`, espresso rose `#573A35` / wine `#741C31`, muted gold `#B58A62`, and soft sand `#DCC8B7`.

## Run locally

1. Install Node.js LTS from https://nodejs.org/.
2. Extract this project folder and open it in VS Code.
3. Open Terminal in the project folder and run:

   ```bash
   npm install
   npm run dev
   ```

4. Open http://localhost:3000.

## Included in this starter

- Responsive fashion storefront homepage
- Brand header, hero, category cards, story and newsletter sections
- Product cards, category filters, search and price sorting
- Interactive wishlist and shopping bag/cart drawer
- Custom blouse enquiry link (WhatsApp link currently uses a generic destination)
- Supplied brand logo at `public/aura-logo.png`
- Supplied visual reference at `public/design-reference.png`

## Important before production

This is a polished frontend starter, not yet a live transactional store. Product images and product information are demo content and must be replaced/verified. Customer login, protected admin dashboard, database/inventory, shipping, real checkout, payment provider, order emails, and WhatsApp business number are not connected. Do not accept payments or store customer information until these services are configured securely. Add secrets only through local environment variables and deployment environment settings; never commit secrets to GitHub.

## Deploy

Push the project to a GitHub repository and import that repository into https://vercel.com/. Set any required environment variables after the backend is configured, then deploy and connect the domain.
