import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Aura by Preethi | Curated specially for you', description: 'Discover timeless sarees, beautifully crafted blouses and designs made just for you.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
